# Obra de Josep Puig i Cadafalch: inventari revisat amb fonts

*Base: «Obra total de Puig» (PDF, maig 2020, 218 entrades). Revisió i ampliació: novembre 2026.*
*Full de càlcul de treball: https://claude.ai/artifact/Uxb18m3krp3d4NN3ca1U4C*

## Com llegir aquest document

Cada fitxa porta el número del PDF i el nom de l'obra. Després van les dades en aquest ordre: adreça, any, estat de conservació, protecció i estat de la revisió. Quan la dada nova no coincideix amb el PDF, el valor del PDF va entre parèntesis. Les fonts fan servir les abreviatures de la [bibliografia](#bibliografia-i-abreviatures) del final.

**Estats de la revisió**

- `Confirmada`: l'obra i l'autoria queden documentades en una font fiable.
- `Ampliada`: s'han afegit dades noves, com l'adreça, la protecció o l'estat.
- `Parcial`: hi ha informació, però no ho resol tot.
- `Discrepància`: les fonts contradiuen el PDF o es contradiuen entre elles.
- `Duplicat`: l'obra ja surt en una altra fila.
- `Hipòtesi`: hi ha una identificació probable, però no està verificada.
- `Nota`: la fila és un aplec d'obres.
- `Sense dades noves`: no s'ha trobat res més.
- `Pendent`: no s'ha trobat res.

## Errors i discrepàncies principals del PDF

**Municipi equivocat**

- Cal Maimó (#206) és a **Tàrrega**, no a Terrassa.
- La Granja Sobrevia (#215) és a **Seva**, no a Vilafranca.
- La Colònia obrera Ybern (#92) era per a **Mollerussa**, no per a Barcelona.

**Nom equivocat**

- El monument de Vilafranca (#214) és a Manuel **Milà** i Fontanals, no a Macià.

**Duplicats**

| Fila | És la mateixa obra que |
|---|---|
| #18 Esteve Andorrà (1896) | #78 Serralleria Esteve Andorrà (1915) |
| #99 Panteó Brustau | #45 Panteó Terrades |
| #42 i #47 | Casa Polo-Caballol (repetida) |
| #34 i #43 | Casa Llorach (repetida) |
| #37 i #39 | Bar Torino (repetit) |
| #144 Casa Valls | #145 Casa Sisternes |
| #174 i #177 | Abat Oliba (repetit) |
| #175 i #178 | Santa Cecília (repetida) |
| #200 Caves Codorniu | #198 Cellers Codorniu |
| #68 i #89 | Casa Joaquim Carreras (repetida) |
| #56 Pou de ferro i ceràmica | #54 Brollador del Palau de Belles Arts |
| #61 i #90 | Fàbrica Casarramona (repetida) |
| #25 i #28 | Estudi Napoleon / pis d'Emili Fernández (Rambla de Santa Mònica): probablement la mateixa obra |
| #27 i #31 | Antic Hotel Europa / Casa Martí i Puig (Boqueria, 12): probablement el mateix edifici |
| #70, #71 i #79 | Joieria, magatzem i casa Miele (Ferran, 2): la mateixa obra |
| #19 i #113 | Panteó de la família Joan Macià (1896 i 1932): mateix nom; possible duplicat |
| #137 i «Vila Blanca» | La «Casa Pich» de Llavaneres seria Vila Blanca (hipòtesi) |

**Altres discrepàncies**

- **Casino de Mataró (#160):** el catàleg municipal l'atribueix a Jeroni Boada.
- **Can Carreras de Sarrià (#68):** segons el MUHBA es conserva, però el PDF la dona per desapareguda.
- **Pis de Prat de la Riba (#105):** el MUHBA el data el 1917, i el PDF el 1929-32.
- **Casa Maria Guarro (#101):** Romeu la situa a la Via Laietana; el MUHBA, a Sant Pere Més Alt, 46.
- **Creu de la Misericòrdia de Canet (#123):** L'oeuvre (1904) ja la publica, però l'IPAC la data el 1910.
- **Cabot i Barba (#162):** és al c. Churruca, 90, no al 35-41.
- **Creu d'en Ramis (#148):** és al Camí Ral, no a la plaça de Santa Anna.
- **Casa Sisternes (#145):** el PDF la dona en bon estat; el catàleg de 1999 diu que cal una intervenció urgent.

---

## Obres del PDF

### Alella
- **#1 Reforma de la casa Guarro** · 1944 · `Sense dades noves`
  Possible relació amb Can Sanmiquel (propietat posterior de Marià Guarro). — [Diba: can-sanmiquel](https://patrimonicultural.diba.cat/element/can-sanmiquel)
- **#2 Can Sanmiquel** · Av. St. Josep de Calasanz, 55 · 1914 · Bo · BCIL (Catàleg d'Alella 2010) · `Ampliada`
  L'ampliació de 1914 és «atribuïda per alguns» a Puig. — [Diba: can-sanmiquel](https://patrimonicultural.diba.cat/element/can-sanmiquel)

### Andorra
- **#3 Hotel pel Sr. Lacruz (Casa Lacruz)** · Av. Carlemany, 61, Escaldes-Engordany · 1940-1941 (PDF: 1942) · Correcte · Bé immoble inventariat · `Ampliada`
  Romeu (tesi, p. 822) en parla com a «Hotel d'Andorra», encàrrec cap al 1941. — [Viqui], [WD Q5047841](https://www.wikidata.org/wiki/Q5047841), [Romeu-v2]

### Argentona
- **#4 Casa Puig i Cadafalch** · C. Dolors Monserdà, 3-5 · 1897-1905 · Regular/mitjà, en restauració · BCIN 276-MH-EN · `Ampliada`
  Diba: la fusteria i la pèrgola estan en mal estat. — [IPAC 303](https://invarquit.cultura.gencat.cat/card/303), [Diba: can-puig-i-cadafalch](https://patrimonicultural.diba.cat/element/can-puig-i-cadafalch)
- **#5 Capella del Sagrament** · Pl. de l'Església, 1 · 1897 · Bo / molt bo · `Ampliada`
  Diba hi posa «protecció inexistent», mentre que el PDF diu BCIL: cal verificar-ho. — [Diba: capella-del-sagrament](https://patrimonicultural.diba.cat/element/capella-del-sagrament), [Viqui]
- **#6 Decoració de la sala de Can Calopa** · C. Bernat de Riudemeia, 8 · 1898 (PDF: 1899) · Bo · BCIL 9795-I · `Ampliada`
  Reformes en un casal preexistent: tanca, portalada i sala. — [IPAC 8322](https://invarquit.cultura.gencat.cat/card/8322), [Diba: can-calopa-mas-batlle](https://patrimonicultural.diba.cat/element/can-calopa-mas-batlle), [Viqui]
- **#7 Casino** · 1929 (XB: 1899 i 1929) · Desaparegut · `Parcial`
  Enderrocat; al seu lloc s'hi va fer un edifici nou. — [Fonts, CEA Jaume Clavell](https://raco.cat/index.php/Fonts/article/download/128759/178305/178302)
- **#8 Casa Josep Garí** · Camí de Sant Miquel del Cros, 9 (PDF: núm. 8) · 1898-1900 · Bo · BCIN 283-MH-EN · `Ampliada`
  — [IPAC 310](https://invarquit.cultura.gencat.cat/card/310), [Diba: can-gari](https://patrimonicultural.diba.cat/element/can-gari), [WD Q3661109](https://www.wikidata.org/wiki/Q3661109)
- **#9 Projecte d'hivernacle (Can Garí, el Cros)** · 1900-04 · No existeix · `Confirmada`
  L'oeuvre (1904) publica el «Projet de serre ouverte pour le château Garí». — [AC: masoveria-de-can-gari](https://www.arquitecturacatalana.cat/en/works/masoveria-de-can-gari), [Oeuvre] pàg. n105
- **#10 Altar de la Santíssima** · 1939 · `Hipòtesi`
  La capella del Santíssim de Sant Julià (Puig, 1897) es va cremar durant la guerra. L'altar de 1939 seria de la reconstrucció de postguerra: el baldaquí imita els romànics i els llums són còpies. — [Diba fitxa PDF](https://patrimonicultural.diba.cat/print/pdf/node/38224)
- **#11 Casa Baladia (Minguell)** · Pg. Baró de Viver, 56 · 1888 (Viqui) / 1893 (IPAC) · Bo / molt bo · BCIL 9839-I · `Ampliada`
  Avui és un restaurant. L'IPAC esmenta Puig i Ramon Ribera; l'autoria continua dubtosa. — [IPAC 45097](https://invarquit.cultura.gencat.cat/card/45097), [Viqui]
- **#12 Torre d'aigües** · Av. Molí de les Mateves s/n (pati de l'antiga Gütermann, el Cros) · 1898 (IPAC) / 1900 · Bo · BCIL 9872-I · `Ampliada`
  Atribuïda a Puig. És la torre de l'antiga masoveria de Can Garí (Can Sorrall). — [IPAC 8332](https://invarquit.cultura.gencat.cat/card/8332), [Diba: diposit-elevador-de-can-gari-torre-gutterman](https://patrimonicultural.diba.cat/element/diposit-elevador-de-can-gari-torre-gutterman)

### Badalona
- **#13 Quiosc Anís del Mono** · Pl. de l'Estació · 1896-1900 · Desaparegut (va estar gairebé quatre dècades a l'andana) · `Ampliada`
  Fet per a Vicenç Bosch. El Quiosc de l'Arpa de Barcelona en copia el disseny, i el publica L'oeuvre (1904). — [Ara](https://es.ara.cat/economia/empresas/leyenda-102-monos-anis_1_4959664.amp.html), [AC: quiosc-de-larpa](https://www.arquitecturacatalana.cat/en/works/quiosc-de-larpa), [Oeuvre] pàg. n29

### Barcelona
- **#14 Joieria Macià** · C. Ferran, 18 · 1893-94 · Desapareguda · `Confirmada`
  Publicada a L'oeuvre: «Orfèvrerie Macià», façana i interior. — [Viqui], [Oeuvre] pàg. n41
- **#15 Bandera per Pons i Gallarza** · 1895 · `Confirmada`
  Tapís per als Jocs Florals en memòria del poeta. — [Romeu-cron] 1895
- **#16 Casa Alfred Riera** · C. Nàpols, 166 (baixos) · 1895 · `Confirmada`
  És una reforma de la planta baixa. El MUHBA (núm. 02) la dona per no documentada. — [MUHBA], [Romeu-cron] 1895
- **#17 Casa Martí (Els Quatre Gats)** · C. Montsió, 3 bis / Ptge. del Patriarca, 1 · 1895-1896 · Bo · BCIN 55-MH · `Ampliada`
  — [IPAC 59](https://invarquit.cultura.gencat.cat/card/59), [WD Q3661125](https://www.wikidata.org/wiki/Q3661125)
- **#18 Equipament comercial Esteve Andorrà** · C. Sant Pau, 69 · 1896? · Desaparegut · `Duplicat` de #78
  Al MUHBA (núm. 41) és una decoració de 1915. Andorrà ja havia treballat amb Puig a la Joieria Macià. — [MUHBA], [Fontbona]
- **#19 Panteó de la família Joan Macià** · 1896 · `Pendent`
- **#20 Monument a Rius i Taulet** · 1897 · Projecte per a concurs · `Confirmada`
  — [Oeuvre] pàg. n26
- **#21 Panteó de la família Dam** · Cementiri de Montjuïc, via St. Josep, agrup. 2a, núm. 52 · 1896-1899 · `Confirmada`
  Panteó J. Dam i Montells (MUHBA núm. 04), amb forja de Masriera & Campins (Fontbona). — [Commons](https://commons.wikimedia.org/wiki/Category:Montju%C3%AFc_Cemetery), [MUHBA], [Oeuvre] pàg. n27
- **#22 Casa Romà Macaya** · Pg. Sant Joan, 108 · 1898-1901 · Bo · BCIN 56-MH · `Ampliada`
  — [IPAC 60](https://invarquit.cultura.gencat.cat/card/60)
- **#23 Oficines de La Veu de Catalunya** · Rambla de les Flors, 25 · c. 1900 · Desaparegudes · `Ampliada`
  Redacció del diari; MUHBA núm. 09. — [MUHBA]
- **#24 Casa Amatller** · Pg. de Gràcia, 41 · 1898-1900 · Bo · BCIN 38-MH-EN · `Ampliada`
  — [IPAC 42](https://invarquit.cultura.gencat.cat/card/42)
- **#25 Casa A. Fernández («Napoleon»)** · La Rambla, 18 / Pl. Joaquim Xirau, 3 · 1900 · Totalment transformada (Frontó Colom, 1941) · Protecció urbanística · `Ampliada`
  Estudi del fotògraf Napoleon (MUHBA núm. 08). Probablement és la mateixa obra que #28. — [AC: estudi-fotografic-napoleon](https://www.arquitecturacatalana.cat/ca/obres/estudi-fotografic-napoleon), [WD Q124623954](https://www.wikidata.org/wiki/Q124623954), [Viqui], [MUHBA]
- **#26 Casa Muntadas** · Av. Tibidabo, 48 / C. Lluís Muntadas, 10 · 1901 (PDF: 1899) · Bo · BCIL 4144-I · `Ampliada`
  — [IPAC 329](https://invarquit.cultura.gencat.cat/card/329), [WD Q11912772](https://www.wikidata.org/wiki/Q11912772), [Oeuvre] pàg. n88
- **#27 Antic Hotel Europa** · C. Boqueria, 12 / C. Quintana, 2 · 1898 · Bo · BCIL 3989-I · `Ampliada`
  Possiblement és la mateixa obra que la Casa Martí i Puig (#31). — [IPAC 40322](https://invarquit.cultura.gencat.cat/card/40322), [AC: casa-francesc-marti-puig](https://www.arquitecturacatalana.cat/ca/obres/casa-francesc-marti-puig)
- **#28 Casa Emili Fernández** · Rambla Santa Mònica, 15-17 · abans de 1904 · `Confirmada`
  Decoració d'un pis («Appartement de M. Émile Fernández»). L'adreça coincideix amb #25. — [MUHBA], [Oeuvre] pàg. n133
- **#29 Projecte de Laboratori Ferran** · 1901 · `Pendent`
- **#30 Projecte de Restaurant al Tibidabo** · 1901 · `Pendent`
- **#31 Casa Martí i Puig** · C. Boqueria, 12 (façana al c. Quintana) · 1901-02 · BCIL · `Ampliada`
  Cal revisar si és un duplicat de #27. — [AC: casa-francesc-marti-puig](https://www.arquitecturacatalana.cat/ca/obres/casa-francesc-marti-puig)
- **#32 Hotel Terminus** · C. Aragó, 282 · 1902 · Desaparegut (anys 60) · `Ampliada`
  — [Viqui], [Oeuvre] pàg. n95
- **#33 Casa Capella** · C. Marià Cubí, 90 · 1902 · Desapareguda · `Ampliada`
  — [AC: casa-capella](https://www.arquitecturacatalana.cat/ca/obres/casa-capella), [Viqui], [Oeuvre] pàg. n93
- **#34 Casa Llorach** · C. Muntaner, 263 (Viqui i MUHBA: 265) · 1903-1904 · Desapareguda c. 1930-35 · `Ampliada`
  Duplicat de #43. — [AC: casa-llorach](https://www.arquitecturacatalana.cat/ca/obres/casa-llorach), [WD Q20155770](https://www.wikidata.org/wiki/Q20155770), [MUHBA]
- **#35 Fanals del carrer dels Escudellers** · 1903 · Desapareguts · `Confirmada`
  — [MUHBA] núm. 20
- **#36 Palau del Baró de Quadras** · Av. Diagonal, 373 / C. Rosselló, 279 · 1904-1906 (PDF: 1902) · Bo · BCIN 41-MH · `Ampliada`
  — [IPAC 45](https://invarquit.cultura.gencat.cat/card/45), [WD Q2362262](https://www.wikidata.org/wiki/Q2362262)
- **#37 Projecte de decoració del Bar Torino** · Pg. de Gràcia, 18 · 1902 · Desaparegut · `Ampliada`
  És la mateixa obra que #39. — [Viqui], [WD Q21009301](https://www.wikidata.org/wiki/Q21009301)
- **#38 Torre Capella** · Sant Gervasi · 1902 · `Sense dades noves`
  Possiblement relacionada amb la Casa Capella (#33).
- **#39 Bar Torino** · Pg. de Gràcia, 18 · 1902 · Desaparegut · `Ampliada`
  Duplicat de #37. — [Viqui], [WD Q21009301](https://www.wikidata.org/wiki/Q21009301)
- **#40 Casa Avel·lí Trinxet** · C. Còrsega, 268 · 1902-1905 · Enderrocada el 1967 · `Ampliada`
  Vitralls del taller Rigalt. — [AC: casa-avelli-trinxet](https://www.arquitecturacatalana.cat/ca/obres/casa-avelli-trinxet), [WD Q3820636](https://www.wikidata.org/wiki/Q3820636), [Oeuvre] pàg. n111
- **#41 Casa Pere Serra** · Rambla de Catalunya, 126 / C. Còrsega, 311 · 1903-1907 (MUHBA: 1901-1905) · Bo · BCIN 297-MH · `Ampliada`
  El 1945 J. M. Pericas la va reformar per al Col·legi Teresià. — [IPAC 330](https://invarquit.cultura.gencat.cat/card/330), [MUHBA] núm. 12
- **#42 Casa Polo-Caballol** · Pg. Sant Gervasi, 55-57 (antic núm. 149) · 1904 · Enderrocada el 1956 (MUHBA: 1946) · `Ampliada`
  És la «Maison Caballol» de L'oeuvre. Duplicat de #47. — [Viqui], [MUHBA] núm. 23, [Oeuvre] pàg. n104
- **#43 Casa Llorach / Concepció Dolça** · C. Muntaner, 263 · 1903-1904 · Desapareguda · `Ampliada`
  «Maison de Madame Concepción Dolsa». Duplicat de #34. — [AC: casa-llorach](https://www.arquitecturacatalana.cat/ca/obres/casa-llorach), [Oeuvre] pàg. n124
- **#44 Casa Terrades (Les Punxes)** · Av. Diagonal, 416-420 / C. Rosselló, 260-262 · 1903-1905 · Bo · BCIN 42-MH · `Ampliada`
  — [IPAC 46](https://invarquit.cultura.gencat.cat/card/46)
- **#45 Panteó de la família Terrades** · Cementiri de Montjuïc, via St. Josep, agrup. 2a, núm. 11 bis · 1905-1911 · Bo · `Ampliada`
  Encàrrec d'Àngela Brutau, vídua de Terradas (1905); l'obra s'acaba el desembre de 1911. Escultura d'Arnau. — [Viqui], [MUHBA] núm. 24, [DRAC] p. 253
- **#46 Fàbrica Casarramona (1a)** · 1903-1904 · `Pendent`
- **#47 Casa Polo-Caballol** · Pg. Sant Gervasi, 55-57 · 1904 · `Ampliada`, duplicat de #42 — [Viqui]
- **#48 Panteó del Baró de Quadras** · Cementiri de Montjuïc · 1900-1904 · `Confirmada`
  — [MUHBA] núm. 11, [Oeuvre] pàg. n135
- **#49 Casa Sastre i Marquès** · C. Eduardo Conde, 44 / Cardenal Vives i Tutó, 29-35 · 1905 · Bo · BCIL 4045-I · `Ampliada`
  — [IPAC 40375](https://invarquit.cultura.gencat.cat/card/40375)
- **#50 Farmàcia Sastre i Marquès** · C. Hospital, 109 / C. Cadena, 2 · 1905 · Desapareguda el 1999 · `Ampliada`
  — [AC: farmacia-del-dr-sastre-i-marques](https://www.arquitecturacatalana.cat/ca/obres/farmacia-del-dr-sastre-i-marques), [WD Q131292838](https://www.wikidata.org/wiki/Q131292838)
- **#51 Casa Macià / Macaya** · 1906, projecte · `Parcial`
  Romeu (cronologia 1912) recull una «Casa palau Macaya: reforma». Cal verificar si és la mateixa intervenció. — [Romeu-cron]
- **#52 Casa Francesc Mercader** · C. Santaló, 8 · 1906 · `Ampliada`
  Xalet Francisco Mercader Zufia. — [AC: xalet-francisco-mercader-zufia](https://www.arquitecturacatalana.cat/ca/obres/xalet-francisco-mercader-zufia)
- **#53 Casa Manuel Ballarín** · C. Venus, 8 i fàbrica del Vapor Vell (c. Perill, Venus i Ròmul Bosch) · 1907-1912 · Desapareguda · `Ampliada`
  Fases de l'obra:
  - 1907: cobert a la fàbrica (AMCB exp. Fo-1552/1907).
  - 1912: reforma del taller i el despatx (#67) i pis al c. Venus, 8.
  
  MUHBA núm. 32. — [MUHBA], [DRAC] p. 276, [Romeu-cron] 1912
- **#54 Brollador de ferro i ceràmica** · Vestíbul del Palau de Belles Arts · 1907 (PDF: 1908) · `Confirmada`
  Font projectada per Puig i forjada als tallers de Ballarín. — [Fontbona], [Àlbum Expo 1907](https://ddd.uab.cat/pub/llibres/1907/209782/recvexpint_a1907.pdf)
- **#55 Casa-taller de M. Pastor de Cruïlles** · Ctra. de Vallvidrera al Tibidabo, 102-104 · 1904-1908 · Bo (Viqui: regular) · BCIL 7166-I · `Ampliada`
  Avui és el col·legi Mater Salvatoris. — [IPAC 331](https://invarquit.cultura.gencat.cat/card/331), [AC: casa-merce-pastor-de-cruilles](https://www.arquitecturacatalana.cat/ca/obres/casa-merce-pastor-de-cruilles), [Oeuvre] pàg. n108
- **#56 Pou de ferro i ceràmica** · Vestíbul del Palau de Belles Arts · 1908 · `Duplicat` probable de #54 — [Fontbona]
- **#57 Tron reial i sala del tron (Jocs Florals)** · 1908 · `Confirmada`
  Ballarín en va forjar elements. — [Fontbona]
- **#58 Casa Àngels Macià Monserdà (Casa Borrell Macià)** · C. Anglí, 58 · 1908-1909 · Correcte · `Ampliada`
  És la mateixa casa que la «Casa Antoni Borrell i Soler» de Wikidata. — [Viqui], [WD Q134987467](https://www.wikidata.org/wiki/Q134987467), [MUHBA] núm. 29
- **#59 Reforma interior del Palau de la Generalitat** · Pl. Sant Jaume, 4 · 1908-1914 · Bo · BCIN 44-MH · `Ampliada`
  — [IPAC 48](https://invarquit.cultura.gencat.cat/card/48)
- **#60 Restauració per a la Biblioteca de Catalunya** · C. del Carme, 47-49 / C. Hospital, 56 · 1908-1914 · Bo · BCIN 29-MH · `Ampliada`
  — [IPAC 33](https://invarquit.cultura.gencat.cat/card/33)
- **#61 Fàbrica Casarramona** · C. Mèxic, 36-44 · 1909-1912 · Bo · BCIN 62-MH · `Ampliada`
  — [IPAC 66](https://invarquit.cultura.gencat.cat/card/66)
- **#62 Base del bust de Víctor Balaguer** · Parc de la Ciutadella · 1910 (inaugurat l'1 de maig) · Art públic · `Ampliada`
  Bust de Manuel Fuxà. — [WD Q99509263](https://www.wikidata.org/wiki/Q99509263), [OldBCN](https://oldbcn.com/en/tourism/public-art/victor-balaguer)
- **#63 Reforma dels carrers de Santa Àgata** · 1910-1914 · `Confirmada`
  Projecte de la pl. de Ramon Berenguer i de l'enllaç amb la Via Laietana (1914), executat per altres (MUHBA núm. 39). — [Lacuesta], [EC](https://www.enciclopedia.cat/EC-GEC-0053080), [MUHBA]
- **#64 Casa Pere Company** · C. Casanova, 203 / Buenos Aires, 56-58 · 1911 · Bo · BCIL 4002-I · `Ampliada`
  — [IPAC 40334](https://invarquit.cultura.gencat.cat/card/40334)
- **#65 Casa Muley Afid** · Pg. Bonanova, 55 / Dalmases, 63 · 1911 (IPAC) / 1914 (Viqui) · Bo · BCIL 3987-I · `Ampliada`
  — [IPAC 40319](https://invarquit.cultura.gencat.cat/card/40319)
- **#66 Barri de la Catedral i Plaça del Rei** · 1911-14 · Projecte d'ordenació · `Confirmada`
  — [DeTorres], [EC](https://www.enciclopedia.cat/EC-GEC-0053080)
- **#67 Tallers i despatx Ballarín** · Entre els carrers Còrsega, Venus i Perill · 1912 · Desapareguts · `Confirmada`
  És un projecte de reforma propi, diferent del cobert de 1907. — [MUHBA], [DRAC] p. 276
- **#68 Casa Joaquim Carreras (finca Santa Margarida)** · C. Sant Pere Claver, 17-21 / Av. Vallvidrera, 34 · 1913-1915? · `Discrepància`
  El MUHBA (núm. 42) diu que es conserva com a Residència Maria Reina; el PDF la dona per desapareguda. Romeu en dona dues obres: una cotxera (1913) i un portal (1921). Duplicat de #89. — [Viqui], [MUHBA], [Romeu-cron]
- **#69 Casa Carreras** · C. Montsió, 5 / Ptge. del Patriarca, 2 · c. 1920 · Bo · BCIL 7337-I · `Ampliada`
  Atribuïda; potser és només una reforma. — [IPAC 42553](https://invarquit.cultura.gencat.cat/card/42553)
- **#70 Joieria Miele** · C. Ferran, 2 / La Rambla · 1914 · Desapareguda · `Ampliada`
  — [AC: orfebreria-miele](https://www.arquitecturacatalana.cat/ca/obres/orfebreria-miele)
- **#71 Magatzem Miele** · C. Ferran, 2 / La Rambla · 1914 · Transformat · `Ampliada`
  — [Viqui], [AC: orfebreria-miele](https://www.arquitecturacatalana.cat/ca/obres/orfebreria-miele)
- **#72 Reforma de casa** · C. Montcada, 19 · 1913 · Desapareguda · `Ampliada`
  — [MUHBA] núm. 37
- **#73 Projecte de l'Exposició Universal (Montjuïc)** · 1913-23 · `Nota`
  Inclou els palaus d'Alfons XIII i Victòria Eugènia, les Quatre Columnes i les escales i el mirador de l'eix. — [AC: escales-mirador](https://www.arquitecturacatalana.cat/ca/obres/escales-mirador-i-escultures-la-terra-laigua-i-dones)
- **#74 Casa M. Garí** · C. Modolell · 1914 · `Parcial`
  Romeu: «Pis a Modolell». — [Romeu-cron] 1914
- **#75 Llums de bronze de la Llotja de Mar** · 1914 · `Pendent`
- **#76 Projecte de la central de Correus** · 1909-1911 (concurs) · `Parcial`
  Puig hi va participar, però l'edifici construït és de Goday i Torres. — [RomeuCosta], [EC art](https://www.enciclopedia.cat/art-de-catalunya/arquitectura-catalana-del-noucentisme-i-academicisme)
- **#77 Projecte de la Plaça de Catalunya** · 1915-1923 · No executat · `Parcial`
  El projecte és de 1915 i es va modificar. Puig va publicar «La plaça de Catalunya» (1927). — [Ribas], [EC](https://www.enciclopedia.cat/EC-GEC-0053080), [Opuscle 1927](https://ddd.uab.cat/pub/llibres/1927/60041/placat_a1927.pdf)
- **#78 Serralleria Esteve Andorrà** · C. Sant Pau, 69 · 1914-1915 · Desapareguda · `Confirmada`
  — [MUHBA] núm. 41, [Fontbona]
- **#79 Casa Miele** · C. Ferran, 2 · 1916 · `Ampliada`
  Probablement és la mateixa obra que #70 i #71. — [Viqui]
- **#80 Casa de la Colla de l'Arròs** · Pg. Santa Madrona, 16 (Montjuïc) · c. 1917-1919 · Destruïda el 1973 · `Confirmada`
  Reforma d'un edifici existent al Roserar. No és el restaurant de la Font del Gat, que és una altra obra (Pg. Santa Madrona, 28; vegeu «Obres no al PDF»): la fitxa IPAC 42745 correspon a la Font del Gat. — [MUHBA] núm. 48, [Romeu-Mjc] p. 383
- **#81 Casa Puig i Cadafalch** · C. Provença, 231 · 1917 (reforma) · Bo (restaurada el 2008) · BCIL 7544-I · `Ampliada`
  — [IPAC 333](https://invarquit.cultura.gencat.cat/card/333)
- **#82 Panteó de la família M. A. Borrell** · 1917 · `Pendent`
- **#83 Panteó de la família Macià** · c. 1904 · `Pendent`
- **#84 Monument a Prat de la Riba (Castellterçol)** · Pl. d'Enric Prat de la Riba · c. 1917 · No realitzat · `Parcial`
  Se'n va posar la primera pedra; la fitxa no n'esmenta l'autor. — [Diba fitxa PDF](https://patrimonicultural.diba.cat/print/pdf/node/84229)
- **#85 Projecte de l'Exposició d'Indústries Elèctriques** · 1913-1917-24 · `Confirmada`
  Encàrrec de 1913. És l'origen de l'Exposició de 1929. — [RomeuCosta], [Ribas]
- **#86 Pis vell Casarramona** · Pg. de Gràcia, 27 (?) · c. 1910? (PDF: 1918) · Desaparegut · `Parcial`
  — [MUHBA] núm. 31
- **#87 Projecte de teatre i carrer nou** · 1918 · `Pendent`
- **#88 Reforma de la Casa Pich i Pon** · Pl. Catalunya, 9 / Rambla de Catalunya, 2 · 1919-1921 · Bo · `Ampliada`
  — [IPAC 41290](https://invarquit.cultura.gencat.cat/card/41290), [WD Q3661140](https://www.wikidata.org/wiki/Q3661140)
- **#89 Casa Joaquim Carreras** · 1919 · `Ampliada`, duplicat de #68 — [MUHBA]
- **#90 Fàbrica Casarramona** · 1920 · `Nota`: és el mateix edifici que #61 — [IPAC 66](https://invarquit.cultura.gencat.cat/card/66)
- **#91 Palaus d'Alfons XIII i Victòria Eugènia** · Montjuïc · 1920-1923 · Bo · BCIL 15521-I i 4106-I · `Ampliada`
  — [IPAC 40439](https://invarquit.cultura.gencat.cat/card/40439), [IPAC 52566](https://invarquit.cultura.gencat.cat/card/52566)
- **#92 Colònia obrera Ybern** → **MOLLERUSSA** · Davant la paperera La Forestal de Urgel · 1920 · No realitzada · `Discrepància` (municipi)
  En conserva 22 plànols l'ANC (Fons Puig i Cadafalch). — [DRAC] p. 122-127, [Romeu-v2] p. 727
- **#93 Quiosc i restaurant Filipines** · c. 1920 · `Pendent`
- **#94 Casa Estanislau Segarra** · C. Rosselló, 168 · 1917 (encàrrec) / 1920 (dos pisos més) · `Confirmada`
  — [MUHBA] núm. 52, [Romeu-v2] p. 717
- **#95 Bazar del Obrero (Sants)** · 1920-21 · `Pendent`
  Era una institució benèfica de l'Acció Social Popular. No s'ha trobat l'edifici. — [ARCA, El Social 1917](https://arca.bnc.cat/arcabib_pro/ca/consulta/registro.do?id=10000316260)
- **#96 Casa August Casarramona** · Pg. de Gràcia, 48-52 · 1921-1924 · Correcte · `Ampliada`
  — [Viqui], [Locus 2018](https://ddd.uab.cat/pub/locus/locus_a2018v16/locus_a2018v16p207.pdf)
- **#97 Casa Lluís Guarro** · Via Laietana, 37 / C. Doctor Joaquim Pou, 3 · 1921-1922 · Bo · Protecció urbanística · `Ampliada`
  Romeu l'estudia com a «Casa de Maria Guarro». La va acabar Fernández Díaz, amb interiors d'Adrià Gual. — [IPAC 50902](https://invarquit.cultura.gencat.cat/card/50902), [WD Q116220817](https://www.wikidata.org/wiki/Q116220817), [Romeu-v3] p. 591
- **#98 Font del Palau de Belles Arts** · 1923 · `Pendent`
- **#99 Panteó de la família Brustau** · Montjuïc · `Duplicat` de #45 (Brutau-Terradas, 1905) — [Commons](https://commons.wikimedia.org/wiki/Category:Montju%C3%AFc_Cemetery), [MUHBA]
- **#100 Casa Garí** · Pg. de Gràcia, 60 · c. 1923 · Desapareguda · `Ampliada`
  Tenia mosaics de Lluís Bru. — [MUHBA] núm. 58, [Fontbona]
- **#101 Casa Maria Guarro** · C. Sant Pere Més Alt, 46 · c. 1923-1925 · `Discrepància`
  El MUHBA (núm. 59) la tracta com una obra pròpia; Romeu identifica Maria Guarro amb Via Laietana (#97). Podria ser la Casa-fàbrica Casas (BCIL 15458-I). Wikidata també recull el núm. 24. — [IPAC 52501](https://invarquit.cultura.gencat.cat/card/52501), [WD Q81332034](https://www.wikidata.org/wiki/Q81332034), [RomeuCosta], [MUHBA], [Romeu-v3]
- **#102 Panteó de la família F. Cambó** · Montjuïc · c. 1920-1930, projecte · `Confirmada`
  — [MUHBA] núm. 53
- **#103 Botiga al Passeig de Gràcia** · 1927 · `Pendent`
- **#104 Casa Pich i Pon / Rosa Alemany** · Av. República Argentina, 6 / Riera de Vallcarca, 5 · 1928-1931 · Correcte · `Ampliada`
  Última obra de Puig a Barcelona. — [Viqui], [RomeuCosta], [MUHBA] núm. 63
- **#105 Casa Prat de la Riba** · C. Provença, 162 · 1917 (MUHBA; PDF: 1929-32) · Desapareguda · `Discrepància`
  Pis de la vídua de Prat. — [MUHBA] núm. 44
- **#106 Cobert per a Josep M. Carbó** · C. de l'Àliga · 1929 · `Confirmada`
  — [MUHBA] núm. 60
- **#107 Monument a Mistral** · Pl. de les Cascades · 1930 · `Confirmada`
  Amb Eusebi Arnau. — [MUHBA] núm. 61
- **#108 Panteó de la família Monserdà** · Montjuïc, via St. Joan Baptista, agrup. 9a, núm. 96 · 1930-1932 · `Confirmada`
  Sepultura de Dolors Monserdà, sogra de Puig. — [MUHBA] núm. 62
- **#109 Instal·lació de l'IEC** · C. del Carme, 47 (Casa de Convalescència) · 1930-1931 · `Confirmada`
  — [Lacuesta], [MUHBA] núm. 64
- **#110 Projecte de monument a Guimerà** · Capdamunt del c. Balmes · 1931 · No realitzat · `Confirmada`
  Columna amb àguila de bronze, com a pal d'una senyera. — [RomeuCosta]
- **#111 Panteó de J. Valldaura** · Montjuïc, via St. Jordi, agrup. 3a, núm. 286 · 1935 (MUHBA; PDF: 1932-34) · `Confirmada`
  — [MUHBA] núm. 66
- **#112 Casa Macià Monserdà** · C. de la Mestrança, 59-61 · 1931 · `Pendent`
- **#113 Panteó de la família Joan Macià** · 1932 · `Pendent`
- **#114 Jardí de l'Hospital de la Santa Creu** · C. Hospital, 56 / C. del Carme, 47-49 · 1933-35 · BCIN 29-MH · `Ampliada`
  — [IPAC 33](https://invarquit.cultura.gencat.cat/card/33)
- **#115 Capella del Col·legi Teresià** · Rambla de Catalunya, 126 · 1945 · Molt transformada · `Ampliada`
  Correspon a la reforma de 1945 de la Casa Serra; el projecte el signa Pericas. — [MUHBA] núm. 12

### Fora de Catalunya i altres municipis
- **#116 Decoració de la Villa Labat (BIARRITZ)** · 1902-08 · `Confirmada`
  La vil·la és de Gustave Huguenin; Puig en va fer la decoració, i L'oeuvre en publica l'escala. — [Culture Trip](https://theculturetrip.com/europe/france/articles/the-most-beautiful-buildings-in-biarritz), [Oeuvre] pàg. n65
- **#117 Projecte d'església votiva (BUENOS AIRES)** · 1908-09 · No realitzat · `Confirmada`
  Amb Josep Goday. — [Bibl-IEC]
- **#118 Decoració de la sala del Foment del Treball Nacional (BRUSSEL·LES)** · 1910 · `Confirmada`
  Pavelló espanyol de l'Exposició Internacional. — [Romeu-cron] 1910
- **#119 Glorieta de fusta (CABRERA DE MAR)** · Escola Sant Feliu · `Parcial`
  És una glorieta metàl·lica octogonal; la fitxa no n'indica l'autor. — [Diba fitxa PDF](https://patrimonicultural.diba.cat/print/pdf/node/41900)
- **#120 Reforma de la masia de Can Moreu (CABRERA DE MAR)** · Camí de Santa Elena, 18 · 1897 · Bo · BCIL 5597-I · `Ampliada`
  — [IPAC 8360](https://invarquit.cultura.gencat.cat/card/8360), [Diba: can-moreu](https://patrimonicultural.diba.cat/element/can-moreu)
- **#121 Balneari Can Titus (CALDES D'ESTRAC)** · 1893 · Desaparegut · `Confirmada`
  — [DRAC] p. 284
- **#122 Casa Titus (CALDES D'ESTRAC)** · 1899 · `Pendent`
- **#123 Creu de terme de la Misericòrdia (CANET)** · 1898 (IPAC: 1910) · Bo · BCIL 7778-I · `Discrepància`
  — [IPAC 8504](https://invarquit.cultura.gencat.cat/card/8504), [Oeuvre] pàg. n43
- **#124 Hostatgeria de la Misericòrdia (CANET)** · Parc de la Misericòrdia · 1914 · Bo · BCIL 7778-I · `Ampliada`
  Avui és restaurant. — [IPAC 8519](https://invarquit.cultura.gencat.cat/card/8519), [Viqui]
- **#125 Fàbrica Carbonell i Susagna (CANET)** · Riera / Torrent de Lledoners, 111 · 1899 · Bo (IPAC) / degradada · BCIL 13442-I · `Ampliada`
  — [IPAC 8515](https://invarquit.cultura.gencat.cat/card/8515), [AC: fabrica-juan-carbonell-reverter](https://www.arquitecturacatalana.cat/ca/obres/fabrica-juan-carbonell-reverter)
- **#126 Misteris de Dolor III i V (CANET)** · `Pendent`
- **#127 Font pública, Pl. Barris (CANET)** · `Pendent`
- **#128 Placa, c. Carles Pasqual (CANET)** · `Pendent`
- **#129 Panteó de la família Garí (ESPLUGUES)** · Cementiri parroquial · 1903-1904 · Regular · `Ampliada`
  — [Viqui], [WD Q30301961](https://www.wikidata.org/wiki/Q30301961)
- **#130 Masia Grabuac (FONT-RUBÍ)** · Barri de Grabuac, 16 · 1902 · Bo · IPAC 2586 · `Ampliada`
  Reforma atribuïda; avui és Cava Ludens. — [Diba: masia-grabuac-cal-fraret](https://patrimonicultural.diba.cat/element/masia-grabuac-cal-fraret), [IPAC 2586](https://invarquit.cultura.gencat.cat/card/2586), [Viqui]
- **#131 Casa Agustí Furriols (LA GARRIGA)** · Rda. del Carril / Carrerada, 1 · 1902-1903 · Bo · BCIL 8996-I · `Ampliada`
  — [IPAC 28874](https://invarquit.cultura.gencat.cat/card/28874)
- **#132 Projecte del Palau de la Pau (L'HAIA)** · 1905, concurs · `Confirmada`
  Amb Josep Goday. — [RomeuCosta]
- **#133 Convent de Santa Maria de Gràcia (L'ESCALA, Empúries)** · 1914-1917 · Bo · BCIN 4165-MH · `Ampliada`
  — [IPAC 38360](https://invarquit.cultura.gencat.cat/card/38360)
- **#134 Casa M. Marquès / Hotel Llevant (LLAFRANC)** · Platja de Llafranc · 1936 (juny) · `Confirmada`
  Encàrrec de Manuel Marquès per transformar una casa vella en un hotel. — [Romeu-v2] p. 803, [arch-products](https://www.arch-products.com/case-study/surfaces-makes-waves-spanish-hotel)
- **#135 Projecte d'urbanització (LLAVANERES)** · 1920 · No realitzat · `Confirmada`
  Promogut pel Dr. Francesc Gallart Monés. — [DRAC] p. 127
- **#136 Caseta prop de l'estació (LLAVANERES)** · 1921 · `Pendent`
- **#137 Casa Pich (LLAVANERES)** · 1923 · `Hipòtesi`: podria ser Vila Blanca (Sant Vicenç de Montalt; reformes de 1922) — [Diba: vila-blanca](https://patrimonicultural.diba.cat/element/vila-blanca)
- **#138 Creu i capella de camí (LLORET DE MAR, Sant Pere del Bosc)** · 1898 (IPAC) · Capella mitjana / creu bona · BCIL 14616-I i 14617-I · `Ampliada`
  — [IPAC 26823](https://invarquit.cultura.gencat.cat/card/26823), [IPAC 26824](https://invarquit.cultura.gencat.cat/card/26824), [Oeuvre] pàg. n66
- **#139 Panteó de la família Costa i Macià (LLORET)** · Cementiri · 1902 · Correcte · `Ampliada` — [Viqui]
- **#140 Castell del Baró de Quadras (MASSANES)** · Mas de Quadras, Cambrerol · 1900-1903 · Bo · BCIL 15957-I · `Ampliada`
  — [IPAC 26921](https://invarquit.cultura.gencat.cat/card/26921), [AC: castell-del-baro-de-quadres](https://www.arquitecturacatalana.cat/ca/obres/castell-del-baro-de-quadres), [Oeuvre] pàg. n80
- **#141 Casa Manuel de Bofarull (MADRID)** · 1910-1911 · `Ampliada`
  — [WD Q41628669](https://www.wikidata.org/wiki/Q41628669), [Urbipedia](https://www.urbipedia.org/hoja/Carpeta:Jos%C3%A9_Puig_y_Cadafalch)
- **#142 Projecte de ciutat jardí al Pardo (MADRID)** · 1914 · No realitzat · `Confirmada`
  Amb Cebrià de Montoliu i els Güell. — [DRAC] p. 127

### Mataró
- **#143 Escola d'Arts i Oficis** · abans de 1904 · `Confirmada`
  La intervenció són les rajoles. — [Oeuvre] pàg. n40
- **#144 Casa Valls** · Baixada de Sant Simó, 18 · `Duplicat` de #145 — [Mataró]
- **#145 Casa Sisternes** · C. Sant Simó, 18 · 1891-1892 · Dolent (catàleg de 1999) · BCIL 3201-I, nivell B/v · `Discrepància`
  És la primera obra de Puig (fitxa 295 del catàleg). — [IPAC 8699](https://invarquit.cultura.gencat.cat/card/8699), [Mataró]
- **#146 Mercat «El Rengle» (el Tren)** · Pl. Gran · 1892-1893 · Bo · BCIL 3014-I · `Ampliada`
  El mercat és d'Emili Cabanyes; Puig en va reformar la coberta. — [IPAC 8651](https://invarquit.cultura.gencat.cat/card/8651), [Mataró] fitxa 121
- **#147 Casa Parera** · C. Nou, 20 · 1894 · Bo / regular · BCIL 3072-I · `Ampliada`
  — [IPAC 8671](https://invarquit.cultura.gencat.cat/card/8671), [Mataró] fitxa 164
- **#148 Restauració de la creu d'en Ramis** · Camí Ral – La Rambla (PDF: Pl. Santa Anna) · 1892 · Destruïda el 1936, reconstruïda en part al Museu · BCIL 3116-I · `Discrepància`
  — [IPAC 8723](https://invarquit.cultura.gencat.cat/card/8723)
- **#149 Botiga «La Confiança»** · C. Sant Cristòfol, 10 · 1894-1896 · Bo (restaurada el 2001) · BCIL 3171-I · `Ampliada`
  — [IPAC 8700](https://invarquit.cultura.gencat.cat/card/8700), [Mataró] fitxa 266
- **#150 Hospital de Sant Jaume i Santa Magdalena** · C. Hospital, 31 · 1896 · Projecte no realitzat · `Parcial`
  — [Mataró] fitxa 133
- **#151 Can Cardoner** · La Riera, 95 · abans de 1925 · Bo · BCIL 3136-I · `Ampliada`
  Disseny de Puig, executat pel serraller Antoni March. — [IPAC 8720](https://invarquit.cultura.gencat.cat/card/8720), [Mataró]
- **#152 Casa de Caritat (Beneficència)** · C. Sant Josep, 9 · 1894-1895 · Bo · BCIL 3188-I · `Ampliada`
  Avui és la Creu Roja. — [IPAC 8695](https://invarquit.cultura.gencat.cat/card/8695), [AC: casa-de-beneficencia](https://www.arquitecturacatalana.cat/ca/obres/casa-de-beneficencia)
- **#153 Sala de sessions de l'Ajuntament** · La Riera, 48 · 1893 · `Ampliada`
  L'enteixinat es conserva. — [Viqui], [Mataró] fitxa 220
- **#154 Casa natal familiar** · C. Carreró, 39 · Protecció integral, nivell A · `Ampliada`
  Puig hi va fer el cos annex al pati. La finca es va vendre el juny del 2026. — [Mataró] fitxa 98, [Bonart](https://www.bonart.cat/en/n/46782/disappointment-over-the-sale-of-josep-puig-i-cadafalch39s-birthplace-in-mataro)
- **#155 Casa a la façana de mar («per salvar nàufrags»)** · c. 1894 · Desapareguda · `Pendent`
- **#156 Bandera de la comissió de Mataró a Ripoll** · 1893 · `Confirmada`
  Estendard votiu de l'Associació Artístic-Arqueològica Mataronesa, amb Cabanyes. — [Graupera], [Coll], [Oeuvre] pàg. n46
- **#157 Façana del Teatre Clavé** · C. de Montserrat / Rambla, 40 · 1901 · Bo (restaurada el 1992) · BCIL 3118-I · `Ampliada`
  Puig va fer la façana del c. de Montserrat. El teatre es va enderrocar el 1978. — [IPAC 411](https://invarquit.cultura.gencat.cat/card/411), [Mataró] fitxa 212
- **#158 Unes quaranta cases de cos anònimes** · 1893-99 · `Pendent`
- **#159 Casa Coll i Regàs** · C. d'Argentona, 55 · 1897 · Bo · BCIN 363-MH-EN · `Ampliada`
  — [IPAC 416](https://invarquit.cultura.gencat.cat/card/416)
- **#160 Casino Mercantil** · La Riera, 38-40 · 1897 · Mitjà · `Discrepància`
  El catàleg (fitxa 218) l'atribueix a Jeroni Boada. — [Mataró]
- **#161 Edifici a la Riera, 46** · inici del s. XX · Bo · BCIL 3125-I · `Ampliada`
  Reforma del finestral gòtic, amb Eusebi Arnau. — [IPAC 8719](https://invarquit.cultura.gencat.cat/card/8719), [Mataró] fitxa 219
- **#162 Reforma de la fàbrica Cabot i Barba** · C. Churruca, 90 (PDF: 35-41) · 1897 · Mitjà · BCIL 2996-I · `Discrepància`
  — [IPAC 39751](https://invarquit.cultura.gencat.cat/card/39751), [Mataró] fitxa 102
- **#163 Altar del convent de les Caputxines** · 1946 (PDF: 1947) · `Ampliada`
  — [Mataró] fitxa 116
- **#164 Xarxa de clavegueram** · 1892-1896 · `Confirmada`
  Projecte i direcció de Puig com a arquitecte municipal, amb el Dr. Viladevall. — [Graupera], [Romeu-cron] 1895, [Fulls MASMM](https://raco.cat/index.php/FullsMASMM/article/download/128619/219216)
- **#165 Casa Joan Puig i Bruguera** · C. Santa Teresa, 40 · 1929 · Bo · Sense protecció · `Ampliada`
  — [IPAC 53160](https://invarquit.cultura.gencat.cat/card/53160)
- **#166 Capelles de Santa Maria (Santa Llúcia, Sant Josep)** · c. 1945 · `Parcial`
  — [Fulls MASMM](https://raco.cat/index.php/FullsMASMM/article/download/137115/316969)

### Moià i Montserrat
- **#167 Casa del tenor Francesc Viñas (MOIÀ)** · C. Ricard Wagner, 1 · 1906-1908 · Dolent · `Ampliada`
  Diba només li atribueix el colomar. — [Diba: cases-vinas-villa-mercedes](https://patrimonicultural.diba.cat/element/cases-vinas-villa-mercedes)
- **#168 V Misteri de Dolor** · Camí de la Santa Cova (Collbató) · 1896 · Bo · `Ampliada`
  Amb Josep Llimona. — [Diba: cinque-misteri-de-dolor](https://patrimonicultural.diba.cat/element/cinque-misteri-de-dolor), [WD Q23782675](https://www.wikidata.org/wiki/Q23782675)
- **#169 III Misteri de Goig** · Camí de la Santa Cova · 1901 · Bo · `Ampliada`
  — [Diba: tercer-misteri-de-goig](https://patrimonicultural.diba.cat/element/tercer-misteri-de-goig), [WD Q23782669](https://www.wikidata.org/wiki/Q23782669)
- **#170 Estació del cremallera** · 1904? · `Parcial`
  Només es documenta l'espai de l'estació superior dins la reforma de les places (1929). — [femturisme](https://www.femturisme.cat/ca/establiments/cremallera-i-funiculars-de-montserrat)
- **#171 Claustre i reforma de la biblioteca** · 1917 i 1923-28 · BCIL 1304-I · `Ampliada`
  — [IPAC 16806](https://invarquit.cultura.gencat.cat/card/16806), [Lacuesta], [RomeuCosta]
- **#172 Reforma del refetor** · 1925-1928 · `Ampliada` — [IPAC 16806](https://invarquit.cultura.gencat.cat/card/16806), [Lacuesta]
- **#173 Façana de l'església i garatge** · 1928 · `Confirmada`
  — [RomeuCosta], [Lacuesta]
- **#174 i #177 Monument a l'abat Oliba** · 1928 · `Duplicat` (fila repetida al PDF)
- **#175 Restauració de Santa Cecília (Marganell)** · 1927-1931 · Bo · `Ampliada`
  — [Diba: santa-cecilia-de-montserrat](https://patrimonicultural.diba.cat/element/santa-cecilia-de-montserrat), [Lacuesta]
- **#176 Creuer neoromànic** · 1925 · `Pendent`
- **#178 Restauració de Santa Cecília** · `Duplicat` de #175

### Altres municipis (P–V)
- **#179 Fundació Cambó (PARÍS, Sorbona)** · 1928-1934 · `Parcial`
  Puig hi va participar, però el mobiliari no està documentat. — [Romeu-cron] 1928
- **#180 Parada per a Comas Blanch (PARÍS, Exposició Universal)** · 1899 · `Pendent`
- **#181 Projecte de Sagristia Nova / Panteó (POBLET)** · 1936 · `Pendent`
- **#182 Edifici de la Telegrafia Marconi (EL PRAT)** · La Ricarda · 1911 · BCIL 122-I · `Ampliada`
  — [IPAC 16773](https://invarquit.cultura.gencat.cat/card/16773)
- **#183 Escola Assís (PREMIÀ DE MAR)** · C. de la Plaça, 35-41 · 1905 · Bo · BCIL 9085-I · `Ampliada`
  L'autoria no està documentada. — [IPAC 8901](https://invarquit.cultura.gencat.cat/card/8901), [Diba: escola-assis](https://patrimonicultural.diba.cat/element/escola-assis)
- **#184 Urnes dels comtes (RIPOLL)** · 1892 · BCIN 182-MH-EN (monestir) · `Parcial`
  — [IPAC 197](https://invarquit.cultura.gencat.cat/card/197)
- **#185 Làpida pel bisbe Morgades (RIPOLL)** · 1893 · `Confirmada`
  Encàrrec de la Unió Catalanista. — [Graupera], [Coll]
- **#186 Altar Monserdà (SABADELL)** · 1925 · `Pendent`
- **#187 Casa Jover i Llissach (SANTPEDOR)** · C. Llissach, 4 · 1917 · BCIL 5457-I · `Ampliada`
  — [IPAC 35560](https://invarquit.cultura.gencat.cat/card/35560), [AC: casa-llissach](https://www.arquitecturacatalana.cat/ca/obres/casa-llissach)
- **#188 Torre d'aigües amb molí de vent (SANTPEDOR)** · c. 1917 · Correcte · BCIL 5457-I · `Ampliada` — [Viqui], [IPAC 35560](https://invarquit.cultura.gencat.cat/card/35560)
- **#189 Restauració de la Catedral (LA SEU D'URGELL)** · 1918 · Bo · BCIN 211-MH-EN · `Ampliada`
  Va treure'n l'ornamentació neoclàssica de guix. — [IPAC 230](https://invarquit.cultura.gencat.cat/card/230)
- **#190 Panteó de la família Joan Casas (SANT FELIU DE GUÍXOLS)** · 1898 · Bo · IPAC 7326 · `Ampliada`
  — [IPAC 7326](https://invarquit.cultura.gencat.cat/card/7326), [Oeuvre] pàg. n109
- **#191 Restauració del Monestir de Sant Benet (SANT FRUITÓS)** · 1907-11 · Mitjà · BCIN 190-MH · `Ampliada` — [IPAC 207](https://invarquit.cultura.gencat.cat/card/207)
- **#192 Restauració del Monestir (SANT JOAN DE LES ABADESSES)** · 1912-17 · Bo · BCIN 196-MH-EN · `Ampliada`
  L'acabà R. Duran i Reynals. — [IPAC 213](https://invarquit.cultura.gencat.cat/card/213)
- **#193 Sant Jaume de Vilanova (SANTA MARIA D'OLÓ)** · 1931-1933 · Bo · `Ampliada`
  — [Diba: esglesia-de-sant-jaume-de-vilanova](https://patrimonicultural.diba.cat/element/esglesia-de-sant-jaume-de-vilanova), [Lacuesta]
- **#194 Ampliació de la masia La Rodoreda (SANTA MARIA D'OLÓ)** · 1943-1947 · `Confirmada`
  — [Diba: rodoreda](https://patrimonicultural.diba.cat/element/rodoreda), [Lacuesta]
- **#195 Restauració de l'absis de Santa Maria (SANT MARTÍ SARROCA)** · Av. del Castell, 99 · 1906 · Bo · BCIN 198-MH · `Ampliada` — [IPAC 215](https://invarquit.cultura.gencat.cat/card/215)
- **#196 Restauracions i excavacions a SANT MIQUEL DE CUIXÀ (Codalet)** · 1936-1938 · `Ampliada`
  Durant les obres es va descobrir la cripta del Pessebre. — [Urbipedia](https://www.urbipedia.org/hoja/San_Miguel_de_Cuix%C3%A1), [Album](https://album-online.com/detail/en/MmEzNDg1MA/josep-puig-i-cadafalch-a-sant-miquel-cuixa-donde-1938-alb3291240)
- **#197 Casa del Dr. Fargas, «El Maset» (SANT QUIRZE SAFAJA)** · 1919 · Bo · IPAC 29489 · `Ampliada`
  — [IPAC 29489](https://invarquit.cultura.gencat.cat/card/29489), [Diba: el-maset-5](https://patrimonicultural.diba.cat/element/el-maset-5)
- **#198 Cellers Codorníu (SANT SADURNÍ)** · 1902-1915 · Bo · BCIN 204-MH · `Ampliada`
  — [IPAC 221](https://invarquit.cultura.gencat.cat/card/221), [Diba: caves-codorniu](https://patrimonicultural.diba.cat/element/caves-codorniu)
- **#199 Torre de Can Codorníu (SANT SADURNÍ)** · 1906 · Molt bo · `Ampliada` — [Viqui], [AC: caves-codorniu](https://arquitecturacatalana.cat/en/works/caves-codorniu)
- **#200 Caves Codorníu** · 1899 · `Duplicat` de #198
- **#201 Baldaquí i pedestal de la Mare de Déu del Claustre (SOLSONA)** · 1924-1928 · BCIN 205-MH-EN · `Ampliada`
  — [IPAC 222](https://invarquit.cultura.gencat.cat/card/222), [MNAC blog](https://blog.museunacional.cat/en/wp-json/wp/v2/posts/10554), [Lacuesta]
- **#202 Casa Reig (SOLSONA)** · 1928 · `Pendent`
- **#203 Casa Maresh de Casarramona (TÀRREGA)** · 1905 · `Sense dades noves`
- **#204 Urbanització de Sant Pere (TERRASSA)** · 1917-anys 1930 · `Confirmada` — [DRAC] p. 583
- **#205 Restauració de les esglésies de Sant Pere (TERRASSA)** · Pl. Rector Homs · Bo · BCIN 1973-MH · `Ampliada` — [IPAC 19833](https://invarquit.cultura.gencat.cat/card/19833)
- **#206 Cal Maimó** → **TÀRREGA** · C. Alonso Martínez, 37 · 1898-1899 · Molt bo · `Discrepància` (municipi)
  L'autoria és dubtosa: Puig o Domènech. — [Viqui], [Surt de casa](https://surtdecasa.cat/ponent/activat/ruta-modernisme-tarrega)
- **#207 Casa Museu Alegre de Sagrera (TERRASSA)** · C. Font Vella, 29-31 · 1911-1912 · Bo · BCIL 6640-I · `Ampliada`
  Amb Melcior Viñals. — [IPAC 28093](https://invarquit.cultura.gencat.cat/card/28093)
- **#208 Caseta a Cambridge (EUA)** · 1926 · `Parcial`
  Aquell any Puig feia cursos a Harvard. — [DRAC] p. 585
- **#209 Piscina pel Sr. Pearson (EUA)** · 1914 · `Hipòtesi`: el client seria Fred Stark Pearson (Barcelona Traction)
- **#210 Botiga Julio Vicente (VALLADOLID)** · 1910 · `Pendent`
- **#211 Casa de Pilar Moragas (VILADECANS)** · Pineda del Remolar · 1917 · Restaurada el 2009 · BCIL 15189-I · `Ampliada`
  — [IPAC 53076](https://invarquit.cultura.gencat.cat/card/53076), [Viqui]
- **#212 Casa Eusebi Bofill (VILADRAU)** · 1898 · `Ampliada` — [Viqui], [Oeuvre] pàg. n78
- **#213 Casa Riera Puig (VILADRAU)** · Pg. de la Sanitat, 1 · 1903 · Bon estat · `Ampliada` — [Viqui], [Oeuvre] pàg. n130
- **#214 Monument a Manuel *Milà* i Fontanals (VILAFRANCA)** · Rambla de Sant Francesc · 1908-1912 · Bo · BCIL · `Discrepància`
  Diba l'atribueix a Monserdà, Fuxà i Arnau; Romeu l'inclou entre les obres de Puig. — [Diba fitxa PDF](https://patrimonicultural.diba.cat/print/pdf/node/73193), [Romeu-cron] 1912
- **#215 Granja Terrades «Sobrevia»** → **SEVA** · Ctra. BV-5303, km 14 · 1901-1904 · Bo · IPAC 24047 · `Discrepància` (municipi)
  — [IPAC 24047](https://invarquit.cultura.gencat.cat/card/24047), [Diba: casal-de-sobrevia](https://patrimonicultural.diba.cat/element/casal-de-sobrevia), [Oeuvre] pàg. n123
- **#216 Casa Florenci Sala (VILANOVA I LA GELTRÚ)** · C. Correu, 89 · 1898 · Bo · BCIL 8023-I · `Ampliada` — [IPAC 32807](https://invarquit.cultura.gencat.cat/card/32807)
- **#217 Altar i retaule de la capella del Sagrament (VILASSAR DE DALT)** · 1898 · `Pendent`
- **#218 Can Feliu (VILASSAR DE MAR)** · 1905 · `Hipòtesi`: podria ser Ca l'Anton Feliu (Vilassar de Dalt), on Puig va fer el portal — [Diba: ca-lanton-feliu](https://patrimonicultural.diba.cat/element/ca-lanton-feliu)

---

## Obres que no són al PDF (34)

| Municipi | Obra | Adreça | Any | Estat / protecció | Nota | Fonts |
|---|---|---|---|---|---|---|
| Andorra la Vella | Sant Esteve (campanar i porta lateral) | Pl. Príncep Benlloch | 1940-42 | Correcte · BIC | Pis superior del campanar, pòrtic i porxo | [Viqui], [WD Q63789](https://www.wikidata.org/wiki/Q63789), [Lacuesta] |
| Barcelona | Les Quatre Columnes | Pl. Puig i Cadafalch | 1919 | Enderrocades el 1928, reconstruïdes el 2010 | | [AC](https://www.arquitecturacatalana.cat/ca/obres/monument-de-les-quatre-columnes), [WD Q1518215](https://www.wikidata.org/wiki/Q1518215) |
| Barcelona | Escales, mirador i escultures de l'eix de Montjuïc | Pg. Cascades | 1916-27 | BCIL | Amb Marès | [AC](https://www.arquitecturacatalana.cat/ca/obres/escales-mirador-i-escultures-la-terra-laigua-i-dones) |
| Barcelona | Modificació del Pla Baixeras (Via Laietana) | Via Laietana | 1907 | | Urbanisme | [AC](https://www.arquitecturacatalana.cat/ca/obres/modificacio-del-pla-baixeras-per-lobertura-de-la-via-laietana) |
| Girona | Primera restauració dels Banys Àrabs | C. Rei Ferran el Catòlic | 1929-30 | | | [AC](https://www.arquitecturacatalana.cat/ca/obres/primera-restauracio-dels-banys-arabs) |
| Seva | Mas Sors | | s. XIX (reforma) | Bo · IPAC 24048 | | [IPAC 24048](https://invarquit.cultura.gencat.cat/card/24048) |
| Seva | Capella de Sobrevia | Ctra. BV-5303, km 14 | 1905 | Bo | | [Diba](https://patrimonicultural.diba.cat/element/capella-de-sobrevia) |
| Arenys de Munt | Can Comulada i jardí | Camí de Santa Cecília | inici s. XX | Bo | Amb Lluís Bru | [IPAC 53115](https://invarquit.cultura.gencat.cat/card/53115) |
| Santa Maria d'Oló | Torre de Vilanova | | anys 1930 | Bo | | [Diba](https://patrimonicultural.diba.cat/element/torre-de-vilanova) |
| Sant Quirze Safaja | Capella del Maset | El Maset | 1909 | Bo | | [Diba](https://patrimonicultural.diba.cat/element/capella-del-maset) |
| Sant Vicenç de Montalt | Vila Blanca (reformes) | Pg. dels Pins, 37 | 1922 | Bo | Fanals, masoveria i interiors | [Diba](https://patrimonicultural.diba.cat/element/vila-blanca) |
| Òrrius | Can Blanc de la Riera (reforma interior) | Ctra. Argentona, 6 | | Bo · Precatàleg | Masia de la família | [Diba](https://patrimonicultural.diba.cat/element/can-blanc-de-la-riera-o-la-casa-blanca) |
| Viladrau | Can Torra o Xalet Espriu | | 1900 | Molt transformada | | [Viqui] |
| Argentona | Can Gaillard | Av. Catalunya, 8 | 1917 | Bo · BCIL 9819-I | Wikidata sí; IPAC no indica autor | [IPAC 45078](https://invarquit.cultura.gencat.cat/card/45078), [WD Q82818465](https://www.wikidata.org/wiki/Q82818465) |
| Montserrat | Places del monestir i edifici del Museu | | 1929 | Bo | | [Diba](https://patrimonicultural.diba.cat/element/places-del-monestir), [Diba](https://patrimonicultural.diba.cat/element/fons-del-museu-de-montserrat) |
| Mataró | Local de ball de «La Popular» | Pl. de Cuba (avui Escola El Pilar) | 1892 | Desaparegut el 1933 | | [Mataró] fitxa 108 |
| Barcelona | Tres cases Mirallès | | abans de 1904 | | | [Oeuvre] pàg. n100 |
| Barcelona | Menjador amb el «sistema Mirallès» | | abans de 1904 | | Projecte | [Oeuvre] pàg. n30 |
| Barcelona | Antic Museu d'Arts Decoratives i Arqueologia (instal·lació) | Antic Arsenal, Ciutadella | 1902 | Desapareguda | MUHBA núm. 13 | [MUHBA] |
| Barcelona | Magatzem i façana (reforma) | C. Esparreguera, 1-7 | 1902 | | MUHBA núm. 18 | [MUHBA] |
| Barcelona | Casa J. Serratosa i Albert | C. Llull / Rambla de Prim | 1911? | Desapareguda | MUHBA núm. 34 | [MUHBA] |
| Barcelona | Restaurant de la Font del Gat | Pg. Santa Madrona, 28 | c. 1915-20 | Conservat | MUHBA núm. 43 | [MUHBA], [IPAC 42745](https://invarquit.cultura.gencat.cat/card/42745) |
| Barcelona | Casa Bertran i Musitu (reformes i jardí) | C. Musitu, 24 | c. 1920-30? | | MUHBA núm. 54 | [MUHBA] |
| Barcelona | Museu d'Arqueologia (instal·lació) | Pg. Santa Madrona, 39-41 | 1935 | Molt modificat | MUHBA núm. 65 | [MUHBA] |
| Barcelona | Senyera de l'Orfeó Català (disseny) | | 1895 | | | [Romeu-cron] |
| Barcelona | Decoració del saló dels Jocs Florals | | 1895 | | | [Romeu-cron] |
| Barcelona | Casa de lloguer a la Gran Via | | 1906 | | | [Romeu-cron] |
| Barcelona | Edifici de Clínicas Solarium (Tibidabo) | | 1908 | | | [Romeu-cron] |
| Barcelona | Reformes d'una finca | Les Corts, 604 | 1917 | | | [Romeu-cron] |
| Barcelona | Portal de Sant Pere Claver i Sant Carles | Vora el pont del tren de Sarrià | 1921 | | | [Romeu-cron] |
| Barcelona | Habitacions en una finca | Pg. Sant Joan | 1929 | | | [Romeu-cron] |
| Esplugues | Habitatges obrers (Banca Social de Previsió) | | 1928 | | Projecte; un altre el 1930 per al Dr. Sastre | [DRAC] p. 127 |
| Mataró | Ornamentació de carrers (IV Centenari de Colom) | | 1892 | No realitzat | | [Sessió Estudis Mataronins](https://raco.cat/index.php/SessioEstudisMataronins/article/download/331055/441826/505386) |
| Mataró | Destral per als bombers municipals | | 1895 | | Puig era cap de bombers | [Fulls MASMM](https://raco.cat/index.php/FullsMASMM/article/download/128619/219216) |

---

## Què queda pendent i on buscar-ho

**Sense cap dada (27 files):**

- **Panteons**
  - #19 i #113 Joan Macià
  - #83 família Macià
  - #82 M. A. Borrell
- **Barcelona**
  - #29 Laboratori Ferran
  - #30 Restaurant del Tibidabo
  - #46 Casarramona (1a)
  - #75 llums de la Llotja
  - #87 teatre i carrer nou
  - #93 quiosc Filipines
  - #95 Bazar del Obrero
  - #98 font del Palau de Belles Arts
  - #103 botiga al Pg. de Gràcia
  - #112 Casa Macià Monserdà
- **Costa del Maresme**
  - #122 Casa Titus
  - #126-128 Canet
  - #136 caseta de Llavaneres
- **Mataró**
  - #155 casa per salvar nàufrags
  - #158 cases de cos
- **Montserrat**
  - #176 creuer
- **Altres**
  - #180 Comas Blanch (París)
  - #181 Poblet
  - #186 Sabadell
  - #202 Solsona
  - #210 Valladolid
  - #217 Vilassar de Dalt

**Fonts recomanades per continuar:**

1. **Barral i Altet, X.: el cens d'obres a *Escrits d'arquitectura, art i política*** (IEC, 2003, p. 81-100). Cal consultar-lo en una biblioteca.
2. **ANC, fons 737 (Fons Puig i Cadafalch).** Té plànols i projectes; es consulta per [Arxius en Línia](https://arxiusenlinia.cultura.gencat.cat), que demana captcha.
3. **Arxiu Municipal Contemporani de Barcelona.** Expedients de llicències d'obres, com ara el Fo-1552/1907.
4. **[ARCA](https://arca.bnc.cat)** (premsa digitalitzada). Cal buscar-hi obra per obra.
5. **Hemeroteques de La Vanguardia i Diario de Mataró.** Serveixen per a les obres de Mataró i Canet.

## Coordenades

Les coordenades són al full de càlcul i als fitxers de dades. Hi ha 240 obres ubicades. Al mapa, les fitxes duplicades es fusionen en un sol punt, i la fitxa principal indica amb quin altre número també figura al PDF. Per això el mapa mostra 222 punts. Queden sense ubicació 12 obres, perquè són objectes o projectes sense lloc conegut.

| Precisió (punts del mapa) | Punts | Què vol dir |
|---|---|---|
| exacta | 94 | Coordenades de Wikidata (a partir de la fitxa IPAC) o de la fitxa de Diba |
| adreça | 28 | Adreça geocodificada amb el [geocodificador de l'ICGC](https://eines.icgc.cat/geocodificador/) |
| lloc | 39 | Edifici o lloc conegut (monestir, cementiri, plaça) |
| aproximada | 37 | Carrer, barri o entorn; hipòtesis i obres desaparegudes sense número |
| municipi | 24 | Només se sap el municipi |

Cal tenir en compte tres coses:
- Els panteons del cementiri de Montjuïc tenen tots el mateix punt, el centre del cementiri.
- Les obres desaparegudes s'han situat a l'adreça actual. Pot no coincidir amb l'antiga numeració.
- Les quatre obres del Palau de Belles Arts (enderrocat) comparteixen un punt aproximat al Passeig de Lluís Companys.

---

## Bibliografia i abreviatures

**Monografies, tesis i catàlegs**

- **[MUHBA]:** *Puig i Cadafalch / BCN*, guia del Museu d'Història de Barcelona, amb 66 obres de Barcelona numerades.
- **[Romeu-cron]:** Romeu, J., tesi doctoral (UPC, 1989), volum amb la cronologia.
- **[Romeu-v2]:** la mateixa tesi, volum amb les obres tardanes, Andorra i Llafranc.
- **[Romeu-v3]:** la mateixa tesi, volum amb la Casa Guarro.
- **[Romeu-Mjc]:** la mateixa tesi, volum dedicat a Montjuïc.
- Fitxa de la tesi a UPCommons: https://upcommons.upc.edu/handle/2117/109354
- **[DRAC]:** *Puig i Cadafalch*, actes del congrés de 2017 (repositori DRAC de la Generalitat). La citació porta el número de pàgina del PDF.
- **[Oeuvre]:** *L'oeuvre de Puig i Cadafalch architecte, 1896-1904* (1904), a Internet Archive. La citació porta la pàgina «nN» de l'Internet Archive (https://archive.org/details/loeuvredepuigcad00puig/page/nN), comprovada amb el text OCR de cada làmina.
- **[Mataró]:** Catàleg del patrimoni arquitectònic de Mataró. Les citacions porten el número de fitxa.

**Articles de l'IEC**

- **[Lacuesta]:** R. Lacuesta, restauracions de Puig.
- **[DeTorres]:** de Torres, urbanisme del barri gòtic.
- **[Fontbona]:** F. Fontbona, arts aplicades i col·laboradors.
- **[RomeuCosta]:** Romeu i Costa, obra arquitectònica tardana.
- **[Coll]:** Coll, Ripoll.
- **[Ribas]:** M. Ribas i Piera, urbanisme.
- **[Graupera]:** J. Graupera, Puig a Mataró (Lambard).
- **[Bibl-IEC]:** bibliografia de Puig publicada per l'IEC.

**Fonts en línia**

- **[Viqui]:** Viquipèdia, «Josep Puig i Cadafalch», secció «Principals obres».
- **IPAC:** Inventari del Patrimoni Arquitectònic de Catalunya (https://invarquit.cultura.gencat.cat/card/N).
- **Diba:** Mapa de patrimoni cultural de la Diputació de Barcelona (https://patrimonicultural.diba.cat).
- **WD:** Wikidata.
- **AC:** arquitecturacatalana.cat.

[MUHBA]: https://www.barcelona.cat/museuhistoria/sites/default/files/guia-puigicadafalch-693x420mm-web.pdf
[Romeu-cron]: https://upcommons.upc.edu/bitstreams/535ceaef-efae-4c23-8592-51bd271824df/download
[Romeu-v2]: https://upcommons.upc.edu/bitstreams/5379653f-79f5-405b-b7f1-2ac2531ed11a/download
[Romeu-v3]: https://upcommons.upc.edu/bitstreams/df190764-1be0-4058-b4c7-cc4cc279f39c/download
[Romeu-Mjc]: https://upcommons.upc.edu/bitstreams/de5f78c1-a154-4866-a69b-1dc9082232c4/download
[DRAC]: https://drac.cultura.gencat.cat/bitstream/handle/20.500.12368/19564/Puig%20i%20Cadafalch%20(1).pdf
[Oeuvre]: https://archive.org/details/loeuvredepuigcad00puig
[Mataró]: https://www.mataro.cat/ca/temes/urbanisme/el-patrimoni-arquitectonic-i-el-paisatge-urba/documents
[Lacuesta]: https://publicacions.iec.cat/repository/pdf/00000379/00000063.pdf
[DeTorres]: https://publicacions.iec.cat/repository/pdf/00000379/00000064.pdf
[Fontbona]: https://publicacions.iec.cat/repository/pdf/00000379/00000066.pdf
[RomeuCosta]: https://publicacions.iec.cat/repository/pdf/00000379/00000067.pdf
[Coll]: https://publicacions.iec.cat/repository/pdf/00000379/00000068.pdf
[Ribas]: https://publicacions.iec.cat/repository/pdf/00000337/00000052.pdf
[Graupera]: https://publicacions.iec.cat/repository/pdf/00000466/00000100.pdf
[Bibl-IEC]: https://publicacions.iec.cat/repository/pdf/00000343/00000057.pdf
[Viqui]: https://ca.wikipedia.org/wiki/Josep_Puig_i_Cadafalch#Principals_obres
